package com.example.jarvis

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var voice: Voice
    private lateinit var brain: JarvisBrain
    private val messages = mutableStateListOf<Pair<String, String>>()
    private var listening by mutableStateOf(false)
    private var busy by mutableStateOf(false)
    private var apiKey by mutableStateOf("")
    private var model by mutableStateOf("gemini-2.5-flash")
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private val permissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        apiKey = prefs.getString("gemini_key", "") ?: ""
        model = prefs.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        brain = JarvisBrain(this, { apiKey }, { model })
        voice = Voice(
            this,
            onHeard = ::handle,
            onListening = { listening = it },
            onFail = { messages.add("Jarvis" to it) }
        )
        permissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS))

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF00E5FF),
                    background = Color(0xFF05070D),
                    surface = Color(0xFF0B1220)
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { JarvisScreen() }
            }
        }
    }

    private fun handle(text: String) {
        if (apiKey.isBlank()) {
            messages.add("Jarvis" to "Please paste your Gemini API key first, sir.")
            return
        }
        messages.add("You" to text)
        busy = true
        lifecycleScope.launch {
            try {
                val reply = brain.ask(text)
                messages.add("Jarvis" to reply)
                voice.speak(reply)
            } catch (e: Exception) {
                messages.add("Jarvis" to "Error: ${e.message}")
            }
            busy = false
        }
    }

    @Composable
    private fun JarvisScreen() {
        var typed by remember { mutableStateOf("") }
        val listState = rememberLazyListState()
        LaunchedEffect(messages.size) {
            if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
        }

        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(16.dp)) {
            Text(
                "J.A.R.V.I.S.",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp
            )
            OutlinedTextField(
                value = apiKey,
                onValueChange = {
                    apiKey = it
                    prefs.edit().putString("gemini_key", it).apply()
                },
                label = { Text("Gemini API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            OutlinedTextField(
                value = model,
                onValueChange = {
                    model = it
                    prefs.edit().putString("gemini_model", it).apply()
                },
                label = { Text("Gemini model") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { (who, text) ->
                    Text(
                        "$who: $text",
                        color = if (who == "You") Color.White else MaterialTheme.colorScheme.primary
                    )
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 4.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = typed,
                    onValueChange = { typed = it },
                    placeholder = { Text("Type a command") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (typed.isNotBlank()) {
                            handle(typed)
                            typed = ""
                        }
                    },
                    modifier = Modifier.padding(start = 8.dp)
                ) { Text("Send") }
            }
            Button(
                onClick = { if (!listening) voice.listen() },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            ) { Text(if (listening) "Listening…" else "🎤  Speak") }
        }
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }
}
