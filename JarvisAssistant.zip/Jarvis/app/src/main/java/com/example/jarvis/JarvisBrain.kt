package com.example.jarvis

import android.app.Activity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** The "brain": sends your command to Claude, runs any phone tools it asks for, returns the spoken reply. */
class JarvisBrain(
    private val activity: Activity,
    private val apiKey: () -> String,
    private val model: String = "claude-sonnet-5-5"
) {
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private val history = JSONArray()

    private val system = """
        You are J.A.R.V.I.S., a witty, efficient voice assistant living on the user's Android phone.
        Your replies are spoken aloud: keep them to one or two short sentences, no markdown, no lists.
        Use your tools to act on the phone whenever the user asks for an action. Chain several tools if needed.
        Answer general questions directly from your own knowledge.
        If something is impossible on Android (e.g. silently toggling Wi-Fi), say so and use the closest option.
        Address the user as "sir" now and then, but don't overdo it.
    """.trimIndent()

    suspend fun ask(userText: String): String = withContext(Dispatchers.IO) {
        history.put(JSONObject().put("role", "user").put("content", userText))
        repeat(6) {
            val content = call().getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))

            val results = JSONArray()
            val text = StringBuilder()
            for (n in 0 until content.length()) {
                val block = content.getJSONObject(n)
                when (block.getString("type")) {
                    "text" -> text.append(block.getString("text"))
                    "tool_use" -> {
                        val out = withContext(Dispatchers.Main) {
                            Tools.execute(activity, block.getString("name"), block.getJSONObject("input"))
                        }
                        results.put(
                            JSONObject()
                                .put("type", "tool_result")
                                .put("tool_use_id", block.getString("id"))
                                .put("content", out)
                        )
                    }
                }
            }
            if (results.length() == 0) {
                trimHistory()
                return@withContext text.toString().trim()
            }
            history.put(JSONObject().put("role", "user").put("content", results))
        }
        "I seem to be going in circles, sir. Please try again."
    }

    private fun call(): JSONObject {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", system)
            .put("tools", Tools.definitions)
            .put("messages", history)
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey())
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("API ${r.code}: ${s.take(200)}")
            return JSONObject(s)
        }
    }

    /** Drop the oldest whole turns, always keeping tool_use/tool_result pairs together. */
    private fun trimHistory() {
        while (history.length() > 20) {
            var next = 1
            while (next < history.length() && history.getJSONObject(next).opt("content") !is String) next++
            if (next >= history.length()) break
            repeat(next) { history.remove(0) }
        }
    }
}
