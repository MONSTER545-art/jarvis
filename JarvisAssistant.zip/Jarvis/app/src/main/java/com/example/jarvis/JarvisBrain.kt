package com.example.jarvis

import android.app.Activity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** The "brain": sends your command to Google Gemini, runs any phone tools it asks for, returns the spoken reply. */
class JarvisBrain(
    private val activity: Activity,
    private val apiKey: () -> String,
    private val model: () -> String
) {
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private val history = JSONArray()
    private val declarations: JSONArray by lazy { buildDeclarations() }

    private val system = """
        You are J.A.R.V.I.S., a witty, efficient voice assistant living on the user's Android phone.
        Your replies are spoken aloud: keep them to one or two short sentences, no markdown, no lists.
        Use your tools to act on the phone whenever the user asks for an action. Chain several tools if needed.
        Answer general questions directly from your own knowledge.
        If something is impossible on Android (e.g. silently toggling Wi-Fi), say so and use the closest option.
        Address the user as "sir" now and then, but don't overdo it.
    """.trimIndent()

    suspend fun ask(userText: String): String = withContext(Dispatchers.IO) {
        history.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))
        )
        repeat(6) {
            val resp = call()
            val content = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (content == null || parts == null) {
                trimHistory()
                return@withContext "I can't help with that one, sir."
            }
            if (!content.has("role")) content.put("role", "model")
            // Keep the model turn exactly as received (Gemini 3 needs its thought signatures echoed back).
            history.put(content)

            val replies = JSONArray()
            val text = StringBuilder()
            for (n in 0 until parts.length()) {
                val p = parts.getJSONObject(n)
                val fc = p.optJSONObject("functionCall")
                if (fc != null) {
                    val name = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    val out = withContext(Dispatchers.Main) { Tools.execute(activity, name, args) }
                    replies.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name).put("response", JSONObject().put("result", out))
                        )
                    )
                } else if (p.has("text") && !p.optBoolean("thought", false)) {
                    text.append(p.getString("text"))
                }
            }
            if (replies.length() == 0) {
                trimHistory()
                return@withContext text.toString().trim().ifEmpty { "Done, sir." }
            }
            history.put(JSONObject().put("role", "user").put("parts", replies))
        }
        "I seem to be going in circles, sir. Please try again."
    }

    private fun call(): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", history)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations)))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/${model().trim()}:generateContent"
        val req = Request.Builder()
            .url(url)
            .header("x-goog-api-key", apiKey().trim())
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (r.code == 429) error("Free limit reached. Wait a minute and try again.")
            if (!r.isSuccessful) error("Gemini ${r.code}: ${s.take(300)}")
            return JSONObject(s)
        }
    }

    /** Convert the tool list in Tools.kt into Gemini's functionDeclarations format. */
    private fun buildDeclarations(): JSONArray {
        val out = JSONArray()
        val defs = Tools.definitions
        for (n in 0 until defs.length()) {
            val d = defs.getJSONObject(n)
            val schema = d.getJSONObject("input_schema")
            val props = schema.getJSONObject("properties")
            val fn = JSONObject().put("name", d.getString("name")).put("description", d.getString("description"))
            if (props.length() > 0) {
                val p = JSONObject()
                val keys = props.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = props.getJSONObject(k)
                    p.put(
                        k,
                        JSONObject().put("type", v.getString("type").uppercase())
                            .put("description", v.getString("description"))
                    )
                }
                val params = JSONObject().put("type", "OBJECT").put("properties", p)
                val req = schema.getJSONArray("required")
                if (req.length() > 0) params.put("required", req)
                fn.put("parameters", params)
            }
            out.put(fn)
        }
        return out
    }

    private fun isUserPrompt(m: JSONObject): Boolean =
        m.optString("role") == "user" && m.getJSONArray("parts").getJSONObject(0).has("text")

    /** Drop the oldest whole turns, always keeping function call/response pairs together. */
    private fun trimHistory() {
        while (history.length() > 20) {
            var next = 1
            while (next < history.length() && !isUserPrompt(history.getJSONObject(next))) next++
            if (next >= history.length()) break
            repeat(next) { history.remove(0) }
        }
    }
}
