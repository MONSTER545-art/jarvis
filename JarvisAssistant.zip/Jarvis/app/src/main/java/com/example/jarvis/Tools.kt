package com.example.jarvis

import android.app.Activity
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

/** Everything Jarvis can physically do on the phone. Add a tool = add a definition + a `when` branch. */
object Tools {

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun int(desc: String) = JSONObject().put("type", "integer").put("description", desc)
    private fun bool(desc: String) = JSONObject().put("type", "boolean").put("description", desc)

    private fun tool(
        name: String,
        desc: String,
        props: Map<String, JSONObject> = emptyMap(),
        required: List<String> = emptyList()
    ): JSONObject {
        val p = JSONObject()
        props.forEach { (k, v) -> p.put(k, v) }
        return JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
            )
    }

    val definitions: JSONArray = JSONArray().apply {
        put(tool("open_app", "Open an installed app by name.", mapOf("name" to str("App name, e.g. WhatsApp")), listOf("name")))
        put(tool("call", "Open the dialer with a contact's number ready. The user presses the call button.", mapOf("who" to str("Contact name or phone number")), listOf("who")))
        put(tool("send_sms", "Open the SMS app with a drafted message. The user presses send.", mapOf("who" to str("Contact name or phone number"), "message" to str("Message text")), listOf("who", "message")))
        put(tool("set_alarm", "Set an alarm at a clock time (24h).", mapOf("hour" to int("0-23"), "minute" to int("0-59"), "label" to str("Alarm label")), listOf("hour", "minute")))
        put(tool("set_timer", "Start a countdown timer.", mapOf("seconds" to int("Duration in seconds"), "label" to str("Timer label")), listOf("seconds")))
        put(tool("flashlight", "Turn the flashlight on or off.", mapOf("on" to bool("true = on")), listOf("on")))
        put(tool("web_search", "Search the web in the browser.", mapOf("query" to str("Search query")), listOf("query")))
        put(tool("navigate", "Show a place or directions in the maps app.", mapOf("destination" to str("Place or address")), listOf("destination")))
        put(tool("play_music", "Play music by song, artist or genre in the default music app.", mapOf("query" to str("What to play")), listOf("query")))
        put(tool("set_volume", "Set media volume.", mapOf("percent" to int("0-100")), listOf("percent")))
        put(tool("open_settings", "Open a system settings screen (Android does not allow silent toggling).", mapOf("panel" to str("One of: wifi, bluetooth, airplane, display, sound, general")), listOf("panel")))
        put(tool("open_camera", "Open the camera app."))
        put(tool("get_battery", "Get battery percentage."))
        put(tool("get_time", "Get the current date and time."))
    }

    fun execute(a: Activity, name: String, i: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(a, i.getString("name"))
                "call" -> {
                    val who = i.getString("who")
                    val n = findNumber(a, who) ?: return "No contact or number found for $who."
                    go(a, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")), "Dialer opened for $who. User must press call.")
                }
                "send_sms" -> {
                    val who = i.getString("who")
                    val n = findNumber(a, who) ?: return "No contact or number found for $who."
                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", i.getString("message"))
                    go(a, intent, "Message drafted to $who. User must press send.")
                }
                "set_alarm" -> {
                    val intent = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, i.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, i.getInt("minute"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Jarvis alarm"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    go(a, intent, "Alarm set for %02d:%02d.".format(i.getInt("hour"), i.getInt("minute")))
                }
                "set_timer" -> {
                    val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, i.getInt("seconds"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Jarvis timer"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    go(a, intent, "Timer started for ${i.getInt("seconds")} seconds.")
                }
                "flashlight" -> {
                    val cm = a.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val id = cm.cameraIdList.firstOrNull {
                        cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    } ?: return "This device has no flashlight."
                    cm.setTorchMode(id, i.getBoolean("on"))
                    "Flashlight ${if (i.getBoolean("on")) "on" else "off"}."
                }
                "web_search" -> {
                    val q = i.getString("query")
                    go(a, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))), "Searching for $q.")
                }
                "navigate" -> {
                    val d = i.getString("destination")
                    go(a, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(d))), "Showing $d on the map.")
                }
                "play_music" -> {
                    val q = i.getString("query")
                    val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                        .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                        .putExtra(SearchManager.QUERY, q)
                    go(a, intent, "Asked the music app to play $q.")
                }
                "set_volume" -> {
                    val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val pct = i.getInt("percent").coerceIn(0, 100)
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, pct * max / 100, AudioManager.FLAG_SHOW_UI)
                    "Volume set to $pct%."
                }
                "open_settings" -> {
                    val intent = when (i.getString("panel").lowercase()) {
                        "wifi" ->
                            if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                            else Intent(Settings.ACTION_WIFI_SETTINGS)
                        "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                        "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
                        "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                        "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
                        else -> Intent(Settings.ACTION_SETTINGS)
                    }
                    go(a, intent, "Settings opened. User must flip the switch; Android blocks silent toggling.")
                }
                "open_camera" -> go(a, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Camera opened.")
                "get_battery" -> {
                    val bm = a.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    "Battery is at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%."
                }
                "get_time" -> DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT).format(Date())
                else -> "Unknown tool: $name"
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

    private fun go(a: Activity, intent: Intent, okMsg: String): String {
        a.startActivity(intent)
        return okMsg
    }

    @Suppress("DEPRECATION")
    private fun openApp(a: Activity, name: String): String {
        val pm = a.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?: return "No installed app matches \"$name\"."
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "Cannot launch ${match.loadLabel(pm)}."
        a.startActivity(intent)
        return "Opened ${match.loadLabel(pm)}."
    }

    private fun findNumber(ctx: Context, who: String): String? {
        if (who.none { it.isLetter() } && who.any { it.isDigit() }) return who
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$who%"),
            null
        )
        c?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }
}
