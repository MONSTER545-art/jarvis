# Jarvis (Android) - Gemini version

1. Get a free key at aistudio.google.com (menu > Get API key). It starts with AIza.
2. Build the APK (Android Studio, or the GitHub Actions workflow) and install it.
3. Allow microphone + contacts when asked.
4. Paste the key into the app. Leave the model as is unless it errors; if it does,
   copy the model ID shown in AI Studio (Get code) into the "Gemini model" box.
5. Tap Speak.

Add abilities in Tools.kt: one definition in `definitions`, one branch in `execute`.
