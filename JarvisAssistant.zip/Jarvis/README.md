# Jarvis (Android)

1. Install Android Studio (latest), then File > Open > this folder. Let Gradle sync.
2. Plug in a phone (USB debugging on) or start an emulator, press Run.
3. Allow microphone + contacts when asked.
4. Paste your Anthropic API key (console.anthropic.com) into the app, tap Speak.

Try: "Open WhatsApp", "Set an alarm for 6:30", "Timer for 10 minutes", "Turn on the flashlight",
"Play Coldplay", "Navigate to the nearest pharmacy", "What's my battery?", "Call Mom".

Add abilities in Tools.kt: one definition in `definitions`, one branch in `execute`.
The API key is stored on the phone. That is fine for personal use; for anything you ship,
route calls through your own server instead.
